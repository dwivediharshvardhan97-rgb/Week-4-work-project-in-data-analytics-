# Week 4 — Predictive Modeling and Optimization in Logistics

A student project forecasting shipment delivery time with a hypothetical 600-record dataset. Compares Linear Regression and Random Forest using an 80/20 holdout split, MAE, RMSE, R², and five-fold CV MAE. Includes preprocessing, feature importance, residual inspection, and operational recommendations in the report.

Dataset is synthetic; conclusions are illustrative, not real carrier performance. Contents: `data/`, `src/predict_logistics.py`, `outputs/` (generated metrics/figures), and DOCX report.
