from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"; FIG=OUT/"figures"; OUT.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True)
df=pd.read_csv(ROOT/"data"/"logistics_hypothetical.csv",parse_dates=["dispatch_date"])
target="delivery_days"
numeric=["distance_km","weight_kg","shipment_volume_units","peak_season","dispatch_weekday"]
categorical=["transport_mode","region"]
X=df[numeric+categorical]; y=df[target]
preprocessor=ColumnTransformer([
 ("numeric",Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler())]),numeric),
 ("categorical",Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore"))]),categorical)])
models={
 "Linear Regression":Pipeline([("preprocess",preprocessor),("model",LinearRegression())]),
 "Random Forest":Pipeline([("preprocess",preprocessor),("model",RandomForestRegressor(n_estimators=250,min_samples_leaf=3,max_features=.85,random_state=42,n_jobs=-1))])}
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.20,random_state=42)
results={}
for name,model in models.items():
 model.fit(X_train,y_train);pred=model.predict(X_test)
 results[name]={"MAE":float(mean_absolute_error(y_test,pred)),
 "RMSE":float(np.sqrt(mean_squared_error(y_test,pred))),"R2":float(r2_score(y_test,pred))}
chosen=models["Random Forest"]
cv=KFold(n_splits=5,shuffle=True,random_state=42)
cv_mae=-cross_val_score(chosen,X_train,y_train,cv=cv,scoring="neg_mean_absolute_error")
chosen.fit(X_train,y_train);pred=chosen.predict(X_test)
results["Random Forest"]["5fold_CV_MAE_mean"]=float(cv_mae.mean())
results["Random Forest"]["5fold_CV_MAE_std"]=float(cv_mae.std())
pd.DataFrame(results).T.to_csv(OUT/"model_metrics.csv")
pd.DataFrame({"actual_delivery_days":y_test.values,"predicted_delivery_days":pred}).to_csv(OUT/"test_predictions.csv",index=False)
names=chosen.named_steps["preprocess"].get_feature_names_out()
importance=pd.DataFrame({"feature":names,"importance":chosen.named_steps["model"].feature_importances_}).sort_values("importance",ascending=False)
importance.to_csv(OUT/"feature_importance.csv",index=False)
(OUT/"metrics.json").write_text(json.dumps(results,indent=2))
plt.figure();plt.scatter(y_test,pred,alpha=.65);lims=[min(y_test.min(),pred.min()),max(y_test.max(),pred.max())];plt.plot(lims,lims,"--");plt.xlabel("Actual days");plt.ylabel("Predicted days");plt.title("Actual vs Predicted Delivery Time");plt.tight_layout();plt.savefig(FIG/"actual_vs_predicted.png",dpi=160);plt.close()
plt.figure();plt.hist(y_test.values-pred,bins=25,edgecolor="black");plt.xlabel("Error: actual − predicted (days)");plt.ylabel("Count");plt.title("Prediction Error Distribution");plt.tight_layout();plt.savefig(FIG/"error_distribution.png",dpi=160);plt.close()
plt.figure();importance.head(12).sort_values("importance").plot(kind="barh",x="feature",y="importance",legend=False);plt.xlabel("Feature importance");plt.title("Top Predictive Features");plt.tight_layout();plt.savefig(FIG/"feature_importance.png",dpi=160);plt.close()
plt.figure();pd.DataFrame(results).T[["MAE","RMSE"]].plot(kind="bar");plt.ylabel("Error (days)");plt.title("Model Error Comparison");plt.tight_layout();plt.savefig(FIG/"model_comparison.png",dpi=160);plt.close()
print(pd.DataFrame(results).T)
print("Outputs saved under outputs/.")
